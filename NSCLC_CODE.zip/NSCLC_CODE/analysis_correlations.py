"""Independent descriptive correlations of NSCLC within-patient lipid shifts.

Inputs are read only. Biological units are five patients, not 306 lipid species.
No correlation P values or confidence intervals are reported.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import platform
import numpy as np
import scipy
from scipy.stats import rankdata, spearmanr
from openpyxl import load_workbook


def read_matrix(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        rows=list(csv.reader(f))
    names=[x.strip() for x in rows[0][1:]]
    records=[]
    for row in rows[1:]:
        if not row or not row[0].strip() or row[0].strip() == 'Labels':
            continue
        records.append((row[0].strip(),[float(v) for v in row[1:]]))
    labels=[r[0] for r in records]
    assert len(labels)==len(set(labels)), 'Duplicate species labels'
    values=np.asarray([r[1] for r in records], dtype=float)
    assert values.shape==(306,len(names))
    assert np.isfinite(values).all() and (values>0).all()
    return labels,names,values


def pearson(x,y):
    xc=x-x.mean()
    yc=y-y.mean()
    return float(np.dot(xc,yc)/np.sqrt(np.dot(xc,xc)*np.dot(yc,yc)))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-dir',type=Path,default=Path(__file__).resolve().parents[1]/'inputs')
    ap.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parents[1]/'reproduced_results/correlations')
    args=ap.parse_args()
    args.output_dir.mkdir(parents=True,exist_ok=True)
    positive=args.input_dir/'Tumor Positive Samples (Fig. 2).csv'
    negative=args.input_dir/'Tumor Negative Samples (Fig. 3).csv'
    labels,pos_names,pos=read_matrix(positive)
    neg_labels,neg_names,neg=read_matrix(negative)
    assert set(labels)==set(neg_labels)
    neg=neg[[neg_labels.index(x) for x in labels]]
    matrix=np.column_stack([pos,neg])
    sample_names=pos_names+neg_names
    assert len(sample_names)==len(set(sample_names))==10
    patients=[10,11,13,14,15]
    sample_columns={name:matrix[:,j] for j,name in enumerate(sample_names)}
    checks=[]
    source_paths=[positive,negative]
    for patient in patients:
        candidates=list(args.input_dir.glob(f'Patient {patient} - Total * (Fig. 1).xlsx'))
        assert len(candidates)==1
        path=candidates[0]
        source_paths.append(path)
        wb=load_workbook(path,read_only=True,data_only=True)
        rows=list(wb['Sheet1'].values)
        wb.close()
        assert rows[0][1:3]==(f'P{patient}-PT',f'P{patient}-NODE')
        by_lipid={}
        for row in rows[1:]:
            label=str(row[0]).strip() if row[0] is not None else ''
            if label in labels:
                assert label not in by_lipid, f'Duplicate XLSX species {patient}: {label}'
                by_lipid[label]=[float(row[1]),float(row[2])]
        assert set(by_lipid)==set(labels)
        from_xlsx=np.asarray([by_lipid[label] for label in labels])
        from_csv=np.column_stack([sample_columns[f'P{patient}-PT'],sample_columns[f'P{patient}-NODE']])
        max_abs=float(np.max(np.abs(from_xlsx-from_csv)))
        assert np.array_equal(from_xlsx,from_csv), (patient,max_abs)
        checks.append({'patient':patient,'matched_species':len(labels),'max_absolute_csv_xlsx_difference':max_abs})
    delta={patient:np.log2(sample_columns[f'P{patient}-NODE']/sample_columns[f'P{patient}-PT']) for patient in patients}
    floor=np.any(matrix<=1e-6,axis=1)
    assert int(floor.sum())==23
    rows=[]
    comparisons=[('Tumour-positive',11,14),('Tumour-positive',11,15),('Tumour-positive',14,15),('Tumour-negative',10,13)]
    masks=[('All species',np.ones(len(labels),dtype=bool)),('Global floor exclusion',~floor)]
    concordance=[]
    for selection,mask in masks:
        for group,a,b in comparisons:
            x,y=delta[a][mask],delta[b][mask]
            r=pearson(x,y)
            rho=pearson(rankdata(x,method='average'),rankdata(y,method='average'))
            assert np.isclose(r,np.corrcoef(x,y)[0,1],rtol=1e-13,atol=1e-13)
            assert np.isclose(rho,spearmanr(x,y).statistic,rtol=1e-13,atol=1e-13)
            rows.append({'selection':selection,'nodal_group':group,'patient_a':f'P{a}','patient_b':f'P{b}','lipid_count':int(mask.sum()),'pearson_r':r,'spearman_rho':rho})
        for group,pats in [('Tumour-positive',[11,14,15]),('Tumour-negative',[10,13])]:
            shifts=np.column_stack([delta[p][mask] for p in pats])
            up=np.all(shifts>0,axis=1)
            down=np.all(shifts<0,axis=1)
            concordance.append({'selection':selection,'group':group,'biological_pairs':len(pats),'lipid_count':int(mask.sum()),'concordant_up':int(up.sum()),'concordant_down':int(down.sum()),'concordant_total':int((up|down).sum())})
    with (args.output_dir/'within_group_shift_correlations.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)
    with (args.output_dir/'patient_log2_shift_vectors.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['Lipid','At_numerical_floor_in_any_NSCLC_specimen']+[f'P{p}_log2_Node_PT' for p in patients])
        for j,label in enumerate(labels):w.writerow([label,int(floor[j])]+[float(delta[p][j]) for p in patients])
    metadata={
        'method':'Pearson correlation of log2(Node/Primary) vectors; Spearman is Pearson correlation of average ranks. No additional centring/scaling across samples or species before vector construction.',
        'biological_unit':'patient',
        'independent_patient_count':5,
        'excluded_comparator':'P12, non-malignant Aspergillus-associated disease comparator',
        'interpretation':'Coefficients describe these lipid-shift profiles only. Lipids are interdependent; coefficients are not tests of population-level reproducibility and no inferential P values are reported.',
        'species_count':306,
        'positive_negative_species_order_identical':labels==neg_labels,
        'xlsx_checks':checks,
        'numerical_floor':1e-6,
        'floor_affected_species':[label for label,affected in zip(labels,floor) if affected],
        'retained_species':int((~floor).sum()),
        'correlations':rows,
        'concordance_checks':concordance,
        'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths},
        'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
    }
    (args.output_dir/'correlation_analysis.json').write_text(json.dumps(metadata,indent=2))
    print(json.dumps({'xlsx_checks':checks,'correlations':rows,'concordance_checks':concordance},indent=2))

if __name__=='__main__':
    main()
