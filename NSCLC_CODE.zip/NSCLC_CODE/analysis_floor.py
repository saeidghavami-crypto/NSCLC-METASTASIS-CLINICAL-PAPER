"""Independent numerical-floor sensitivity audit. Source files are read-only.

Dependencies: numpy, pandas, scipy, openpyxl. Source workbooks are read only. The global exclusion matches the
uploaded ML script: remove any species <= 1e-6 in any of the ten NSCLC specimens.
P12 is assessed descriptively and never enters the NSCLC mask or group tests.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import re

import numpy as np
import openpyxl
import pandas as pd
from scipy.stats import ttest_1samp

parser = argparse.ArgumentParser(description='Reproduce descriptive numerical-floor sensitivity in paired NSCLC lipidomics.')
parser.add_argument('--input-dir', type=Path, required=True, help='Folder containing the two original CSV files and six patient Excel files.')
parser.add_argument('--output-dir', type=Path, default=Path('floor_sensitivity_results'))
args = parser.parse_args()
BASE = args.input_dir.resolve()
OUT = args.output_dir.resolve()
OUT.mkdir(parents=True, exist_ok=True)
FLOOR = 0.000001
PATIENTS = [11, 14, 15, 10, 13]


def read_csv(path):
    frame = pd.read_csv(path, skiprows=[1], index_col=0)
    frame.index = frame.index.str.strip()
    assert frame.index.is_unique
    assert np.isfinite(frame.values).all() and (frame.values > 0).all()
    return frame


def classify(label):
    for prefix, result in [('LPC (O-', 'LPC(O)'), ('PC(O-', 'PC(O)'),
                           ('PC(P-', 'PC(P)'), ('PE(O-', 'PE(O)'),
                           ('PE(P-', 'PE(P)')]:
        if label.startswith(prefix):
            return result
    if re.match(r'^C(?:14|16|18|20)(?:-| )', label):
        return 'Carnitine'
    return label.split()[0]


def bh(p):
    p = np.asarray(p)
    order = np.argsort(p)
    adjusted = np.minimum.accumulate((p[order] * len(p) / np.arange(1, len(p)+1))[::-1])[::-1]
    result = np.zeros(len(p))
    result[order] = np.minimum(1, adjusted)
    return result


positive = read_csv(BASE / 'Tumor Positive Samples (Fig. 2).csv')
negative = read_csv(BASE / 'Tumor Negative Samples (Fig. 3).csv')
assert positive.index.equals(negative.index)
all_nsclc = pd.concat([positive, negative], axis=1)
labels = positive.index
assert len(labels) == 306
floor = all_nsclc.le(FLOOR).any(axis=1)
assert floor.sum() == 23
classes = pd.Series([classify(s) for s in labels], index=labels)
summary = {
    'definition': 'Global exclusion of any species with abundance <= 1e-6 in any of ten specimens from five NSCLC pairs; no rescaling or replacement.',
    'floor_threshold': FLOOR,
    'n_species_all': len(labels),
    'n_species_excluded': int(floor.sum()),
    'n_species_retained': int((~floor).sum()),
    'below_floor_measurements': int(all_nsclc.lt(FLOOR).sum().sum()),
    'sources': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [BASE/'Tumor Positive Samples (Fig. 2).csv', BASE/'Tumor Negative Samples (Fig. 3).csv']},
    'groups': {}, 'patients': {}, 'workbook_csv_comparison': {},
}

species = pd.DataFrame({'Lipid': labels, 'Class': classes.values,
                        'Global_floor_affected': floor.values})

for name, frame, patients in [('tumour_positive', positive, [11,14,15]),
                              ('tumour_negative', negative, [10,13])]:
    delta = pd.DataFrame({f'P{i}': np.log2(frame[f'P{i}-NODE']/frame[f'P{i}-PT']) for i in patients})
    up = delta.gt(0).all(axis=1)
    down = delta.lt(0).all(axis=1)
    concordant = up | down
    local_floor = frame.le(FLOOR).any(axis=1)
    pvals = pd.Series(ttest_1samp(delta.to_numpy(), popmean=0, axis=1).pvalue, index=labels)
    means = delta.mean(axis=1)
    nominal = concordant & means.abs().gt(1) & pvals.lt(.05)
    fullq = pd.Series(bh(pvals), index=labels)
    retainedq = pd.Series(bh(pvals[~floor]), index=labels[~floor])
    summary['groups'][name] = {
        'patients': patients,
        'all': {'n':306, 'concordant':int(concordant.sum()), 'up':int(up.sum()),'down':int(down.sum()), 'percentage':float(concordant.mean()*100)},
        'global_exclusion': {'n':int((~floor).sum()), 'concordant':int((concordant&~floor).sum()),'up':int((up&~floor).sum()),'down':int((down&~floor).sum()),'percentage':float(concordant[~floor].mean()*100),'removed_concordant_species':labels[concordant&floor].tolist()},
        'group_only_exclusion': {'n_excluded':int(local_floor.sum()),'n_retained':int((~local_floor).sum()),'concordant_retained':int((concordant&~local_floor).sum()),'up_retained':int((up&~local_floor).sum()),'down_retained':int((down&~local_floor).sum()),'excluded_species':labels[local_floor].tolist()},
        'nominal_concordant_absmean_gt1_p_lt05': {'all_n':int(nominal.sum()),'global_exclusion_n':int((nominal&~floor).sum()),'removed':labels[nominal&floor].tolist(), 'all_up':int((nominal&up).sum()),'all_down':int((nominal&down).sum()), 'retained_up':int((nominal&up&~floor).sum()),'retained_down':int((nominal&down&~floor).sum())},
        'min_bh_q_all':float(fullq.min()), 'min_bh_q_retained':float(retainedq.min()),
        'bh_significant_all':int((fullq<.05).sum()), 'bh_significant_retained':int((retainedq<.05).sum()),
        'concordant_by_class': [],
    }
    for c in classes.unique():
        m=classes.eq(c)
        if (concordant&m).any():
            summary['groups'][name]['concordant_by_class'].append({'class':c,'all_up':int((m&up).sum()),'all_down':int((m&down).sum()),'retained_up':int((m&up&~floor).sum()),'retained_down':int((m&down&~floor).sum())})
    for patient in delta:
        species[f'{patient}_log2_Node_PT'] = delta[patient].values
    species[f'{name}_concordant'] = concordant.values
    species[f'{name}_direction'] = np.where(up,'Higher in node',np.where(down,'Higher in primary','Not concordant'))
    species[f'{name}_mean_log2_Node_PT']=means.values
    species[f'{name}_nominal_p']=pvals.values
    species[f'{name}_BH_q_306']=fullq.values
    species[f'{name}_BH_q_283']=retainedq.reindex(labels).values

for patient in range(10,16):
    candidates = list(BASE.glob(f'Patient {patient} - *.xlsx'))
    if len(candidates) != 1:
        raise ValueError(f'Expected exactly one workbook for Patient {patient}, found {len(candidates)}')
    path = candidates[0]
    book=openpyxl.load_workbook(path,read_only=True,data_only=True)
    rows={str(r[0]).strip(): (r[1],r[2]) for r in book['Sheet1'].iter_rows(values_only=True) if r[0] is not None and str(r[0]).strip() in labels}
    assert len(rows)==306
    df=pd.DataFrame.from_dict(rows,orient='index',columns=['PT','NODE']).reindex(labels).astype(float)
    if patient!=12:
        comparison=all_nsclc[[f'P{patient}-PT',f'P{patient}-NODE']].values
        difference=np.abs(df.values-comparison)
        assert np.max(difference)==0
        summary['workbook_csv_comparison'][f'P{patient}']={'exact_match':True,'n_abundances':612,'max_absolute_difference':float(difference.max())}
    delta=np.log2(df.NODE/df.PT)
    selected=delta.abs().gt(1)
    local_floor=df.le(FLOOR).any(axis=1)
    summary['patients'][f'P{patient}']={
        'source':path.name,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'n_floor_species_in_patient':int(local_floor.sum()),'floor_species_in_patient':labels[local_floor].tolist(),
        'pathway_abs_log2_gt1_all':int(selected.sum()),
        'pathway_abs_log2_gt1_after_global_NSCLC_exclusion':int((selected&~floor).sum()),
        'pathway_abs_log2_gt1_after_patient_specific_exclusion':int((selected&~local_floor).sum()),
        'species_removed_from_patient_input_by_global_exclusion':labels[selected&floor].tolist(),
        'new_floor_species_not_in_NSCLC_mask':labels[local_floor&~floor].tolist(),
    }
    class_all=df.groupby(classes).sum()
    class_after=df.loc[~floor].groupby(classes[~floor]).sum()
    class_local=df.loc[~local_floor].groupby(classes[~local_floor]).sum()
    class_audit=[]
    for c in class_all.index:
        a=float(np.log2(class_all.loc[c,'NODE']/class_all.loc[c,'PT']))
        b=float(np.log2(class_after.loc[c,'NODE']/class_after.loc[c,'PT']))
        d=float(np.log2(class_local.loc[c,'NODE']/class_local.loc[c,'PT']))
        class_audit.append({'class':c,'all_log2_Node_PT':a,
                            'global_exclusion_log2_Node_PT':b,
                            'patient_specific_exclusion_log2_Node_PT':d})
    summary['patients'][f'P{patient}']['class_totals']={
        'n_classes':len(class_audit),
        'node_higher_all':sum(d['all_log2_Node_PT']>0 for d in class_audit),
        'node_higher_global_exclusion':sum(d['global_exclusion_log2_Node_PT']>0 for d in class_audit),
        'node_higher_patient_specific_exclusion':sum(d['patient_specific_exclusion_log2_Node_PT']>0 for d in class_audit),
        'values':class_audit,
    }
    book.close()

species.to_csv(OUT/'species_sensitivity.csv',index=False)
species[species.Global_floor_affected].to_csv(OUT/'excluded_species.csv',index=False)

# For one-component PLS1, the X weight vector is proportional to the
# covariance of each autoscaled predictor with the centred binary response.
# VIP_j = sqrt(p) * abs(w_j) / ||w||. Recompute p and weights after exclusion.
def one_component_vip(frame):
    X = frame.T.to_numpy(dtype=float)
    sd = X.std(axis=0, ddof=1)
    assert (sd > 0).all()
    Z = (X-X.mean(axis=0))/sd
    y = np.asarray([0, 0, 0, 1, 1, 1], dtype=float)
    weights = Z.T @ (y-y.mean())
    return pd.Series(np.sqrt(X.shape[1]) * np.abs(weights) / np.linalg.norm(weights), index=frame.index)

vip_all = one_component_vip(positive)
vip_retained = one_component_vip(positive.loc[~floor])
vip_results = pd.DataFrame({'Global_floor_affected': floor, 'VIP_306': vip_all, 'VIP_283_refitted': vip_retained})
vip_results['Selected_original'] = vip_results.VIP_306.ge(1.4)
vip_results['Selected_after_exclusion'] = vip_results.VIP_283_refitted.ge(1.4)
assert vip_results.Selected_original.sum() == 41
assert vip_results.Selected_after_exclusion.sum() == 38
vip_results.to_csv(OUT/'positive_pathway_input_sensitivity.csv', index_label='Lipid')
summary['positive_pathway_input'] = {
    'rule': 'First-component PLS-DA VIP >= 1.4 after autoscaling without log transformation',
    'original_count': int(vip_results.Selected_original.sum()),
    'refitted_count': int(vip_results.Selected_after_exclusion.sum()),
    'removed': labels[vip_results.Selected_original & ~vip_results.Selected_after_exclusion].tolist(),
    'newly_selected': labels[~vip_results.Selected_original & vip_results.Selected_after_exclusion].tolist(),
}
summary['scope'] = 'Descriptive counts, lipid selection and class-total sensitivity. No rerun of target prediction or KEGG enrichment; no rerun of the logistic-regression analyses.'
(OUT/'sensitivity_summary.json').write_text(json.dumps(summary, indent=2)+'\n')
patient_rows=[]
class_rows=[]
for patient, data in summary['patients'].items():
    patient_rows.append({
        'Patient': patient,
        'Floor_species_in_patient': data['n_floor_species_in_patient'],
        'Original_input_count': data['pathway_abs_log2_gt1_all'],
        'After_global_NSCLC_23_exclusion': data['pathway_abs_log2_gt1_after_global_NSCLC_exclusion'],
        'After_within_patient_exclusion': data['pathway_abs_log2_gt1_after_patient_specific_exclusion'],
        'Comparator_excluded_from_NSCLC_mask': patient == 'P12',
    })
    for row in data['class_totals']['values']:
        class_rows.append({'Patient': patient, **row})
pd.DataFrame(patient_rows).to_csv(OUT/'patient_pathway_input_counts.csv', index=False)
pd.DataFrame(class_rows).to_csv(OUT/'patient_class_total_sensitivity.csv', index=False)
print(json.dumps({'n_retained': summary['n_species_retained'],
                  'concordance_positive': summary['groups']['tumour_positive']['global_exclusion']['concordant'],
                  'concordance_negative': summary['groups']['tumour_negative']['global_exclusion']['concordant'],
                  'positive_pathway_inputs': summary['positive_pathway_input']['refitted_count'],
                  'negative_pathway_inputs': summary['groups']['tumour_negative']['nominal_concordant_absmean_gt1_p_lt05']['global_exclusion_n']}, indent=2))
