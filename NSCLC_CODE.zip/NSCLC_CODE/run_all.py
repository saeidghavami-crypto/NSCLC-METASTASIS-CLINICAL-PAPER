#!/usr/bin/env python3
"""Reproduce the NSCLC model, numerical-floor analysis and shift correlations."""
from pathlib import Path
import argparse
import csv
import hashlib
import importlib.metadata
import json
import math
import os
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REFERENCE_FILES = {'correlations/correlation_analysis.json': 'expected_correlation_analysis.json', 'correlations/patient_log2_shift_vectors.csv': 'expected_patient_log2_shift_vectors.csv', 'correlations/within_group_shift_correlations.csv': 'expected_within_group_shift_correlations.csv', 'floor_sensitivity/excluded_species.csv': 'expected_excluded_species.csv', 'floor_sensitivity/patient_class_total_sensitivity.csv': 'expected_patient_class_total_sensitivity.csv', 'floor_sensitivity/patient_pathway_input_counts.csv': 'expected_patient_pathway_input_counts.csv', 'floor_sensitivity/positive_pathway_input_sensitivity.csv': 'expected_positive_pathway_input_sensitivity.csv', 'floor_sensitivity/sensitivity_summary.json': 'expected_sensitivity_summary.json', 'floor_sensitivity/species_sensitivity.csv': 'expected_species_sensitivity.csv', 'ml/analysis_summary.json': 'expected_analysis_summary.json', 'ml/tables/ML_exact_label_permutations.csv': 'expected_ML_exact_label_permutations.csv', 'ml/tables/ML_exact_multivariate_permutation.csv': 'expected_ML_exact_multivariate_permutation.csv', 'ml/tables/ML_lipid_class_coefficients_LOPO.csv': 'expected_ML_lipid_class_coefficients_LOPO.csv', 'ml/tables/ML_model_sensitivity.csv': 'expected_ML_model_sensitivity.csv', 'ml/tables/ML_patient_predictions.csv': 'expected_ML_patient_predictions.csv', 'ml/tables/clinical_metadata_deidentified.csv': 'expected_clinical_metadata_deidentified.csv', 'ml/tables/numerical_floor_affected_lipids.csv': 'expected_numerical_floor_affected_lipids.csv', 'ml/tables/paired_delta_25_lipid_classes.csv': 'expected_paired_delta_25_lipid_classes.csv', 'ml/tables/paired_delta_306_species.csv': 'expected_paired_delta_306_species.csv'}
REL_TOL = 1e-9
ABS_TOL = 1e-12


def assert_value_equal(actual, expected, location, differences):
    if isinstance(expected, bool):
        if actual is not expected:
            differences.append(location)
    elif isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        if not math.isclose(actual, expected, rel_tol=REL_TOL, abs_tol=ABS_TOL):
            differences.append(location)
    elif isinstance(expected, dict) and isinstance(actual, dict):
        # Software versions are recorded, but are not scientific output values.
        ignored = {'python', 'numpy', 'scipy'}
        keys = set(expected) - ignored
        if set(actual) - ignored != keys:
            differences.append(location + ': keys')
        for key in sorted(keys & set(actual)):
            assert_value_equal(actual[key], expected[key], location + '/' + key, differences)
    elif isinstance(expected, list) and isinstance(actual, list):
        if len(actual) != len(expected):
            differences.append(location + ': length')
        for index, (a, e) in enumerate(zip(actual, expected)):
            assert_value_equal(a, e, location + f'/{index}', differences)
    elif actual != expected:
        differences.append(location)


def verify_outputs(output_dir):
    expected_files = [(ROOT / flat_name, Path(relative))
                      for relative, flat_name in sorted(REFERENCE_FILES.items())]
    if not expected_files:
        return {'status': 'not_available', 'files_checked': 0,
                'reason': 'Reference outputs have not yet been installed.'}
    files = []
    failures = []
    for expected_path, relative in expected_files:
        actual_path = output_dir / relative
        differences = []
        if not actual_path.is_file():
            failures.append(str(relative) + ': missing output')
            continue
        if expected_path.suffix == '.json':
            assert_value_equal(json.loads(actual_path.read_text()),
                               json.loads(expected_path.read_text()), str(relative), differences)
        else:
            with expected_path.open(newline='', encoding='utf-8-sig') as f:
                expected_rows = list(csv.reader(f))
            with actual_path.open(newline='', encoding='utf-8-sig') as f:
                actual_rows = list(csv.reader(f))
            if len(actual_rows) != len(expected_rows):
                differences.append(str(relative) + ': row count')
            for i, (actual_row, expected_row) in enumerate(zip(actual_rows, expected_rows)):
                if len(actual_row) != len(expected_row):
                    differences.append(str(relative) + f': row {i+1} width')
                for j, (actual, expected) in enumerate(zip(actual_row, expected_row)):
                    if actual == expected:
                        continue
                    try:
                        a, e = float(actual), float(expected)
                        same = (math.isnan(a) and math.isnan(e)) or math.isclose(a, e, rel_tol=REL_TOL, abs_tol=ABS_TOL)
                    except ValueError:
                        same = False
                    if not same:
                        differences.append(str(relative) + f': row {i+1}, column {j+1}')
        files.append({'file': str(relative), 'passed': not differences})
        failures.extend(differences)
    return {'status': 'passed' if not failures else 'failed',
            'files_checked': len(files), 'relative_tolerance': REL_TOL,
            'absolute_tolerance': ABS_TOL, 'files': files, 'differences': failures}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=ROOT)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'results')
    parser.add_argument('--verify-only', action='store_true', help='Compare existing outputs with the bundled reference results without rerunning calculations.')
    args = parser.parse_args()
    inputs, output = args.input_dir.resolve(), args.output_dir.resolve()
    if output == ROOT:
        raise ValueError('Choose a separate output directory; this folder contains source code, inputs and reference results.')
    if output == inputs:
        raise ValueError('Inputs and outputs must use separate directories.')
    output.mkdir(parents=True, exist_ok=True)
    if args.verify_only:
        verification = verify_outputs(output)
        (output/'verification_report.json').write_text(json.dumps(verification, indent=2)+'\n')
        print(json.dumps(verification, indent=2))
        if verification['status'] != 'passed':
            raise SystemExit(1)
        return

    provenance = json.loads((ROOT/'provenance.json').read_text())
    hashes = {}
    for name, expected_hash in provenance['input_sha256'].items():
        path = inputs/name
        if not path.is_file():
            raise FileNotFoundError(f'Missing input: {name}')
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != expected_hash:
            raise ValueError(f'Input {name} differs from the supplied dataset. Restore the original file to reproduce this study.')
        hashes[name] = digest

    logs = output/'logs'
    logs.mkdir(exist_ok=True)
    env = os.environ.copy()
    env['MPLBACKEND'] = 'Agg'
    env['MPLCONFIGDIR'] = str(output/'_matplotlib_config')
    jobs = [
        ('ml', [str(ROOT/'analysis_ml.py'),
                '--positive', str(inputs/'Tumor Positive Samples (Fig. 2).csv'),
                '--negative', str(inputs/'Tumor Negative Samples (Fig. 3).csv'),
                '--output', str(output/'ml')]),
        ('floor_sensitivity', [str(ROOT/'analysis_floor.py'),
                               '--input-dir', str(inputs), '--output-dir', str(output/'floor_sensitivity')]),
        ('correlations', [str(ROOT/'analysis_correlations.py'),
                          '--input-dir', str(inputs), '--output-dir', str(output/'correlations')]),
    ]
    for name, argv in jobs:
        print(f'Running {name}...', flush=True)
        result = subprocess.run([sys.executable] + argv, text=True, capture_output=True, env=env)
        (logs/(name+'.stdout.txt')).write_text(result.stdout)
        (logs/(name+'.stderr.txt')).write_text(result.stderr)
        if result.returncode:
            raise RuntimeError(f'{name} failed. See {logs/(name+".stderr.txt")}')

    versions = {'python': platform.python_version()}
    for package in ['numpy','pandas','scipy','scikit-learn','matplotlib','Pillow','openpyxl']:
        versions[package] = importlib.metadata.version(package)
    summary = {'software': versions, 'input_sha256': hashes,
               'ml_random_state': 0, 'exact_label_assignments': 10,
               'scope': 'Supplied-data statistical calculations; no raw mass-spectrometry reprocessing or target/pathway-enrichment rerun.'}
    (output/'run_manifest.json').write_text(json.dumps(summary, indent=2)+'\n')
    verification = verify_outputs(output)
    (output/'verification_report.json').write_text(json.dumps(verification, indent=2)+'\n')
    print(json.dumps({'output_directory': str(output), 'verification':verification['status'],
                      'files_checked':verification['files_checked']}, indent=2))
    if verification['status'] == 'failed':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
